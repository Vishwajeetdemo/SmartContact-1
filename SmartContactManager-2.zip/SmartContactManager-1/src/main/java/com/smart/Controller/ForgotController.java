package com.smart.Controller;

import java.util.Random;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ForgotController {

	@RequestMapping("/forgot")
	public String forgotPassword()
	{
		return "forgot_email_password";
	}
	@PostMapping("/send-otp")
	public String sendOTP(@RequestParam("email") String email)
	{
		Random random=new Random(1000);
		System.out.println("EMAIL="+email);
		//generating otp 4 digit
		
		
		int otp=random.nextInt(99999999);
		System.out.println("OTP"+otp);
		
		//write otp code to email
		
		
		return "verify_otp";
	}
}
