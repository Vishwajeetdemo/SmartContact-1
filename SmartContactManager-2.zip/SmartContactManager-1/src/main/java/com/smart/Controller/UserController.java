package com.smart.Controller;

import java.security.Principal;
import java.util.Optional;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.smart.dao.ContactRepository;
import com.smart.dao.UserRepository;
import com.smart.entities.Contact;
import com.smart.entities.User;
import com.smart.helper.Message;

@Controller
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private ContactRepository contactRepository;

	@ModelAttribute
	public void addCommanData(Model model,Principal principal) {
		String userName=principal.getName();
		System.out.println("USERNAME"+userName);
		
		User user=this.userRepository.getUserByUserName(userName);
		System.out.println("USER"+user);
		model.addAttribute("user",user);
		
	}
	
	@RequestMapping("/home")
	public String dashboard(Model model,Principal principal) {
		
		  model.addAttribute("title","User Dashboard");

		return "normal/user_dashboard";
	}
	//Open form
	  @GetMapping("/add-contact")
	  public String openAddContectForm(Model model)
	  {
		  model.addAttribute("title","Add Contact");
		  model.addAttribute("contact",new Contact());
		  
		return "normal/add_contact_form";  
	  }
	 // add contact
	  @PostMapping("/process-contact")
	  public String processContact(
			  @ModelAttribute Contact contact,
			  Principal principal,HttpSession session)
	  {
		  try {
			  
			  
		  String name=principal.getName();
		  User user=this.userRepository.getUserByUserName(name);
		  
		  
		  
		  //processing and uploding file
		  /*
		  if(file.isEmpty())
		  {
			  // send message
			  System.out.println("File is empty");
		  }else {
			  contact.setImage(file.getOriginalFilename());
			  
			  File f=new ClassPathResource("static/img").getFile();
			   

               Path path= Paths.get(f.getAbsolutePath()
		    		  +File.separator+file.getOriginalFilename());
		      
		
			  Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
			  System.out.println("Image is uplode");
		  }
		  */
		  
		  contact.setUser(user);
		  user.getContact().add(contact);
		  this.userRepository.save(user);
		  
		  System.out.println("DATA"+contact);
		  
		  //message success.....
		  session.setAttribute("message", new com.smart.helper.Message("Contact Is Add Successfull !!","alert-success"));
		  
		  }catch (Exception e){
			  e.printStackTrace();
			  //error message
				session.setAttribute("message", new com.smart.helper.Message("Somth went wrong !!","alert-danger"));

		  }
		  return "normal/add_contact_form";
	  }
	  
	  //Show Contact Handaller
	  @GetMapping("/show_contacts/{page}")
	  public String showContacts(@PathVariable("page") Integer page,Model m,Principal principal)
	  {
		  m.addAttribute("title","Show User Contact");
		   
		  String userName=principal.getName();
		  User user=this.userRepository.getUserByUserName(userName);
		  
		  Pageable pageable=PageRequest.of(page, 3);
		  
		  Page<Contact>contact=this.contactRepository.findContactsByUser(user.getId(),pageable);
		  
		  m.addAttribute("contacts",contact);
		  m.addAttribute("currentPage",page);
		  m.addAttribute("totalPage",contact.getTotalPages());
		 
		  return "normal/show_contacts";
	  }
	  //show contact Details
	  @RequestMapping("/{cid}/contact")
	  public String showContactDetail(@PathVariable("cid") Integer cid,Model model,Principal principal)
	  {
		  System.out.println(cid);
		  
		  Optional<Contact> contactOptional=this.contactRepository.findById(cid);
		  Contact contact=contactOptional.get();
		  
		    String userName=principal.getName();
		    
		    User user=this.userRepository.getUserByUserName(userName);
		     if(user.getId()==contact.getUser().getId())
		     {
		    	 model.addAttribute("contact",contact);
		    	 model.addAttribute("title",contact.getName());
		     }
		     
		  
		  return "normal/contact_detail";
	  }
	  
	  //Delete Handaler
	  @GetMapping("/delete/{cid}")
	  public String deleteContact(@PathVariable("cid") Integer cid,
			  Model model,HttpSession httpSession,Principal principal)
	  {
		  Contact contact=this.contactRepository.findById(cid).get();
		  
		  //check
		 // contact.setUser(null);
		 // this.contactRepository.delete(contact);
		  
		  User user=this.userRepository.getUserByUserName(principal.getName());
		  user.getContact().remove(contact);
		  
		  this.userRepository.save(user);
		  
		  httpSession.setAttribute("message", new Message("Contact Delete Succesfully..","alert-success"));
		  
		  return"redirect:/user/show_contacts/0";
	  }
	  //Update Contact
	  @PostMapping("/update-contact/{cid}")
	  public String updateForm(@PathVariable("cid") Integer cid,Model model)
	  {
		  model.addAttribute("title","update-Contact");
		  
		  Contact contact=this.contactRepository.findById(cid).get();
		  model.addAttribute("contact",contact);
		  
		  return "normal/update_form";
	  }
	  
	  //Update Handaler
	  @RequestMapping(value = "/process-update",method=RequestMethod.POST)
	  public String updateHandaler(@ModelAttribute Contact contact,Model model,
			  HttpSession session,Principal principal)
	  {
		  try {
			  
			  User user=this.userRepository.getUserByUserName(principal.getName());
			  
			  contact.setUser(user);
			  
			  this.contactRepository.save(contact);
			  
			  session.setAttribute("message", new Message("Your Contact is Update","alert-success"));
			  
		  }catch(Exception e)
		  {
			  e.printStackTrace();
		  }
		  System.out.println("CONTACT_NAME"+contact.getName());
		  System.out.println("CONTACT_ID"+contact.getCid());
		  
		  return "redirect:/user/"+contact.getCid()+"/contact";
	  }
	  
	  //Show Profile
	  @GetMapping("/profile")
	  public String yourProfile(Model model)
	  {
		  model.addAttribute("title","Profilr Page");
		  return "normal/profile";
	  }
	  
	  //Handeler
	  @GetMapping("/settings")
	  public String openSetting()
	  {
		  return "normal/settings";
	  }
	  
	  //chang password Handaler
	  @PostMapping("/change-password")
	  public String changpassword(@RequestParam("oldPassword") String oldPassword,
			  @RequestParam("newPassword") String newPassword,
			  Principal principal,
			  HttpSession httpSession)
	  {
		  System.out.println("OLD_PASSWORD"+oldPassword);
		  System.out.println("NEW_PASSWORD"+newPassword);
		  
		 String userName= principal.getName();
		 User currentUsere= this.userRepository.getUserByUserName(userName);
		 
		 if(this.bCryptPasswordEncoder.matches(oldPassword, currentUsere.getPassword()))
		 {
			 currentUsere.setPassword(this.bCryptPasswordEncoder.encode(newPassword));
			 this.userRepository.save(currentUsere);
			 httpSession.setAttribute("message", new Message("Your Password Is Successfull Change","alert-success"));
			  
		 }else {
			 httpSession.setAttribute("message", new Message("Wrong old password","alert-danger"));
			 return "redirect:/user/settings";
		 }
		  
		  return "redirect:/user/home";
	  }
}
